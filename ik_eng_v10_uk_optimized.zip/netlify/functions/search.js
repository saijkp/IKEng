const axios = require('axios');

exports.handler = async (event) => {
    let q = event.queryStringParameters.q || '';
    if (!q) return { statusCode: 200, body: JSON.stringify([]) };

    // UK OPTIMIZATION: Injecting "Nordic/Export" keywords to favor high-quality UK aesthetics
    const ukKeywords = " 出口 北欧"; // "Export" and "Nordic/Scandinavian style"
    const optimizedQuery = q + ukKeywords;

    const options = {
        method: 'GET',
        url: 'https://otapi-1688.p.rapidapi.com/BatchSearchItemsFrame',
        params: { 
            language: 'en', 
            framePosition: '0', 
            frameSize: '30', 
            ItemTitle: optimizedQuery,
            SortBy: 'SaleCount:Desc'
        },
        headers: {
            'x-rapidapi-key': '94d703de80msh2eb28d6ac171df9p1e7d96jsn48a6076fe119',
            'x-rapidapi-host': 'otapi-1688.p.rapidapi.com'
        }
    };

    try {
        const response = await axios.request(options);
        const rawItems = response.data?.Result?.Items?.Items?.Content || [];
        
        // Strict keyword relevance filter
        const originalWords = q.toLowerCase().split(' ');
        
        const results = rawItems
            .filter(item => {
                const title = (item.Title || "").toLowerCase();
                const matches = originalWords.filter(word => title.includes(word)).length;
                return matches >= (originalWords.length / 2);
            })
            .slice(0, 6)
            .map(item => {
                const priceCny = parseFloat(item.Price?.OriginalPrice || item.Price?.Value || 0);
                const pid = item.Id || item.ExternalId;
                const cleanId = pid ? pid.toString().replace(/\\D/g, '') : '';
                
                // UK COST CALCULATION (GBP 0.11 rate + Duty/VAT/Freight overhead)
                const factoryGbp = (priceCny * 0.11).toFixed(2);
                const landedGbp = (priceCny * 0.11 * 1.55 * 1.08).toFixed(2);

                let img = item.MainPictureUrl || item.ImageUrl || "";
                if (img.startsWith('//')) img = 'https:' + img;
                if (img.startsWith('http:')) img = img.replace('http:', 'https:');

                return {
                    title: item.Title || "1688 UK Quality Product",
                    price_cny: priceCny.toFixed(2),
                    factory_gbp: factoryGbp,
                    landed_gbp: landedGbp,
                    img: img,
                    link: cleanId ? `https://detail.1688.com/offer/${cleanId}.html` : 'https://www.1688.com'
                };
            });

        return { 
            statusCode: 200, 
            headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify(results) 
        };
    } catch (error) {
        return { statusCode: 200, body: JSON.stringify([]) };
    }
};